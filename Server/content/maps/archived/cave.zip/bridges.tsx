<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="bridges" tilewidth="32" tileheight="32" tilecount="126" columns="14">
 <image source="Bridges/Wooden_Bridges.png" width="448" height="288"/>
</tileset>
