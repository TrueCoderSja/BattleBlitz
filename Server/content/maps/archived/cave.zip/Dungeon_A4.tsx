<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Dungeon_A4" tilewidth="32" tileheight="32" tilecount="528" columns="24">
 <image source="World of Solaria Demo Pack Update 04/RPG Maker/tilesets/Dungeon_A4.png" width="768" height="720"/>
</tileset>
