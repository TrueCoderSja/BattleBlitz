<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Dungeon_A5" tilewidth="32" tileheight="32" tilecount="288" columns="12">
 <image source="World of Solaria Demo Pack Update 04/RPG Maker/tilesets/Dungeon_A5.png" width="384" height="768"/>
</tileset>
