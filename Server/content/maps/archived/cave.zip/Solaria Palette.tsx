<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Solaria Palette" tilewidth="32" tileheight="32" tilecount="24" columns="6">
 <image source="World of Solaria Demo Pack Update 04/Solaria Palette.png" width="200" height="140"/>
</tileset>
