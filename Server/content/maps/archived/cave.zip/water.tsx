<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="water" tilewidth="32" tileheight="32" tilecount="48" columns="12">
 <image source="Water/Water_Tiles.png" width="384" height="128"/>
</tileset>
