<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="hills" tilewidth="32" tileheight="32" tilecount="70" columns="10">
 <image source="Hills/Hills_tiles.png" width="320" height="224"/>
</tileset>
