<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="t3" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="TX Tileset Stone Ground.png" width="256" height="256"/>
</tileset>
