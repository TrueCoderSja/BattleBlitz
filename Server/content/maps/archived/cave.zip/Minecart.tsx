<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Minecart" tilewidth="32" tileheight="32" tilecount="432" columns="18">
 <image source="World of Solaria Demo Pack Update 04/RPG Maker/characters/Minecart.png" width="576" height="768"/>
</tileset>
