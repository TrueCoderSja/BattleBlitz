<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="land" tilewidth="32" tileheight="32" tilecount="48" columns="12">
 <image source="Arable Land/Arable_Land_Tiles.png" width="384" height="128"/>
</tileset>
