<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="t1" tilewidth="32" tileheight="32" tilecount="5208" columns="8">
 <image source="pokemon_tileset_from_public_tiles_32x32_by_chaoticcherrycake_dab2byf-fullview.png" width="256" height="20832"/>
</tileset>
